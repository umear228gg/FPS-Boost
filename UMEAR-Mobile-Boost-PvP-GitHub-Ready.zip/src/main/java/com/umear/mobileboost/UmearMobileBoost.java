package com.umear.mobileboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticlesMode;

/** Applies a lightweight PvP-oriented mobile preset whenever a world is entered. */
public final class UmearMobileBoost implements ClientModInitializer {
    private ClientWorld lastWorld;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) {
                lastWorld = null;
                return;
            }

            // Re-apply on each world/server join, but never every tick.
            if (client.world != lastWorld) {
                applyPvpMobilePreset(client);
                lastWorld = client.world;
            }
        });
    }

    private static void applyPvpMobilePreset(MinecraftClient client) {
        GameOptions options = client.options;

        // Keep nearby opponents reasonably visible while reducing world workload.
        options.getViewDistance().setValue(6);
        options.getSimulationDistance().setValue(4);
        options.getEntityDistanceScaling().setValue(0.75);

        // Reduce expensive visual effects without removing all combat feedback.
        options.getBiomeBlendRadius().setValue(0);
        options.getParticles().setValue(ParticlesMode.DECREASED);
        options.getAo().setValue(false);

        // A stable 90 FPS cap is a practical starting point for mobile thermals.
        // Users can change it manually in Video Settings after the preset applies.
        options.getMaxFps().setValue(90);
        options.write();
    }
}
