package com.umear.mobileboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticlesMode;

public final class UmearMobileBoost implements ClientModInitializer {
    private ClientWorld last;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (c.world == null) { last = null; return; }
            if (c.world == last) return;
            last = c.world;
            var o = c.options;
            o.getViewDistance().setValue(6);
            o.getSimulationDistance().setValue(4);
            o.getEntityDistanceScaling().setValue(0.75);
            o.getBiomeBlendRadius().setValue(0);
            o.getParticles().setValue(ParticlesMode.DECREASED);
            o.getAo().setValue(false);
            o.getMaxFps().setValue(90);
            o.write();
        });
    }
}
